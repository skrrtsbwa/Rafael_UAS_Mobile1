final Map<String, String> enUs = {
  // Homepage Screen
  "lbl_124": "124",
  "lbl_210": "210",
  "lbl_2203": "2203",
  "lbl_30_45_minutes": "30-45 minutes",
  "lbl_41391": "41391",
  "lbl_7323": "7323",
  "lbl_98": "98",
  "lbl_easy": "Easy",
  "lbl_get_started": "Get started",
  "lbl_hello_joana": "Hello, Joana",
  "lbl_james_nikidaw": "James Nikidaw",
  "lbl_meat": "Meat",
  "lbl_medium": "Medium",
  "lbl_miriam_belina": "Miriam belina",
  "lbl_pasta": "Pasta",
  "lbl_paw_andrea": "Paw Andrea",
  "lbl_popular_creator": "Popular creator",
  "lbl_popular_recipes": "Popular recipes",
  "lbl_see_all": "See all",
  "lbl_skip": "Skip",
  "msg_classic_beef_steak": "Classic Beef Steak",
  "msg_get_your_personalized":
      "Get your personalized recipes recommendation in a 4 steps",
  "msg_recipes_recomendation": "Recipes recomendation",
  "msg_spaghetti_bolognese": "Spaghetti Bolognese",
  "msg_what_do_you_want": "What do you want to cook today?",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
