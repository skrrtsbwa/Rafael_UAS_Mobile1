
# Flutter_RecipeApp

![uas mobile](https://github.com/skrrtsbwa/Rafael_UAS_Mobile/assets/107232220/37b14682-c0d8-4714-960e-3ec668a12dc6)
![image](https://github.com/skrrtsbwa/Rafael_UAS_Mobile/assets/107232220/50c3f916-7bb0-4a96-8278-0b1a4a3c1dd0)
